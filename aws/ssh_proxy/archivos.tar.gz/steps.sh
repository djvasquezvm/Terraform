#Install docker
sudo yum install docker -y

#Start Service
sudo systemctl enable --now docker

#Download and make executable docker compose
sudo curl -L https://github.com/docker/compose/releases/download/1.24.1/docker-compose-Linux-x86_64 -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
docker-compose --version

#Permisos Docker
sudo usermod -aG docker ec2-user
